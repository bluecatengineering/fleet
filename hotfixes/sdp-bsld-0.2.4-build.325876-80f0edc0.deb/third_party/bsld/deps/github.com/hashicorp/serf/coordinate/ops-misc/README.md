# ops-misc

This folder is used to share files that are not part of the Serf binary,
but are useful for operational purposes. For example, upstart scripts.

## Debian/Ubuntu package metadata

Move the ```debian``` directory to the root of the repo, and run ```dpkg-buildpackage```.

